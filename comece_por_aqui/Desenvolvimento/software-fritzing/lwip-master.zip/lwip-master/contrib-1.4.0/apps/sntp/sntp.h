#ifndef __SNTP_H__
#define __SNTP_H__

void sntp_init(void);

#endif /* __SNTP_H__ */
